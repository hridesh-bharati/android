package com.swmansion.rnscreens.gamma.tabs.screen

import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.swmansion.rnscreens.gamma.helpers.ViewIdGenerator

class TabsScreenFragment(
    internal val tabsScreen: TabsScreen,
) : Fragment() {
    internal val requireScreenKey: String by tabsScreen::requireScreenKey
    internal val isPreventNativeSelectionEnabled: Boolean by tabsScreen::preventNativeSelection

    internal val menuItemId: Int = ViewIdGenerator.generateViewId()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View = tabsScreen

    override fun onStart() {
        tabsScreen.eventEmitter.emitOnWillAppear()
        super.onStart()
    }

    override fun onResume() {
        tabsScreen.eventEmitter.emitOnDidAppear()
        super.onResume()
    }

    override fun onPause() {
        tabsScreen.eventEmitter.emitOnWillDisappear()
        super.onPause()
    }

    override fun onStop() {
        tabsScreen.eventEmitter.emitOnDidDisappear()
        super.onStop()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

        // Handle theme change through RN's Appearance.setColorScheme
        tabsScreen.onFragmentConfigurationChange(this, newConfig)
    }
}
