#pragma once

#import <Foundation/Foundation.h>

// These symbols are a stubs for components defined in Gamma project implementation.
// We need these, because we can not really trick codegen to generate code only for components
// that satisfy some condition (e.g. when env var is defined). If these symbols are missing,
// the application will fail in runtime when RN attempts to create components class registry.

NS_ASSUME_NONNULL_BEGIN

@interface RNSStackHostComponentView : NSObject
@end

@interface RNSStackScreenComponentView : NSObject
@end

@interface RNSSplitHostComponentView : NSObject
@end

@interface RNSSplitScreenComponentView : NSObject
@end

@interface RNSScrollViewMarkerComponentView : NSObject
@end

@interface RNSFormSheetHostComponentView : NSObject
@end

@interface RNSStackHeaderConfigComponentView : NSObject
@end

@interface RNSStackHeaderItemComponentView : NSObject
@end

@interface RNSFormSheetContentWrapperComponentView : NSObject
@end

@interface RNSStackHeaderItemSpacerComponentView : NSObject
@end

@interface RNSScrollToTopGuard : NSObject
@end

NS_ASSUME_NONNULL_END
